<?php 
   include("connection.php");
   $conn=connect();
    // public function updateInvoice($POST) {
       if(isset($_POST['nn']))
    {
      $name = $_POST['nn'];
      $sold = $_POST['sold'];

      $sql = "UPDATE `products` SET `quantity`=quantity-'$sold', `sold`=sold +'$sold' WHERE (name = '$name' and quantity - '$sold' >= 0);";
        mysqli_query($conn, $sql);
        header("Location:billpage.php");}
   ?>