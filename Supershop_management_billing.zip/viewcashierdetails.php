<?php
session_start();
include 'connection.php';
$conn=connect();
$query= "select * from cashiertable";
$result = mysqli_query($conn,$query);

?>
<html>
<head>
      <title> Cashier Details </title>
</head>
<body>
  <div align="center">
      <table border="1px" width="600px">
        <tr>
        <th colspan="4"  <h2> Cashier Record</h2> </th>
         </tr>
         <tr>
          <th>Cashier Id</th>
          <th>Cashier Name </th>
          <th>Number </th>
          <th>Cashier Adrress </th>
        </tr>
        <?php
        while($rows=mysqli_fetch_assoc($result))
        {
     ?>
        <tr>
          <td>  <?php echo $rows['cashier_id'] ?>  </td>
            <td>    <?php echo $rows['cashier_name'] ?>     </td>
             <td>    <?php echo $rows['mobile_number'] ?>     </td>
            <td>     <?php echo $rows['address'] ?>    </td>
        </tr>
      <?php
   }
   ?>
      </table>
  </div>
        <li style="float: left;"><a href="dashboard.php" style="padding-left: 380px;"><button type="button" autofocus>Home Page</button></a></li>

</body>
</html>
