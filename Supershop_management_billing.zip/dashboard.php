<?php
session_start();
include 'navigation.php';
include 'connection.php';
$conn=connect();
$sql= "SELECT * from products WHERE updated_at>'$date'";
$prod=$conn->query($sql);
$sql= "SELECT COUNT(*) as products FROM products";
    $total_products= mysqli_fetch_assoc($conn->query($sql));

    $sql= "SELECT SUM(quantity) as total_bought FROM products";
    $total_bought= mysqli_fetch_assoc($conn->query($sql));

    $sql= "SELECT SUM(sold) as total_sold FROM products";
    $total_sold= mysqli_fetch_assoc($conn->query($sql));

    $stock_available= $total_bought['total_bought']-$total_sold['total_sold'];
?>



<html>

<head>
    <title>Dashboard</title>
    <link rel="stylesheet" type="text/css" >
</head>
<body style="background-color:lightblue;">
<div class="row" style="padding-top: 100px;">
    <div class="leftcolumn">
        <div class="row">
            <section style="padding-left: 20px; padding-right: 20px;">
                <div class="col-sm-3">
                        <h3>Total Products </h3>
                        <h2 style="color:black; text-align: center;"><?php echo $total_products['products'] ?></h2>
                </div>
                <div class="col-sm-3">
                        <h3>Products Available </h3>
                        <h2 style="color: black; text-align: center;"><?php echo $total_bought['total_bought'] ?></h2>
                </div>
                <div class="col-sm-3 " >      
                        <h3>Products Sold </h3>
                        <h2 style="color: black; text-align: center;"><?php echo $total_sold['total_sold'] ?></h2>
                </div>
                <div class="col-sm-3" >
                        <h3>Available Stock </h3>
                        <h2 style="color: black; text-align: center;"><?php echo $stock_available ?></h2>                   
                </div>
            </section>
        </div>
        <!-- <div class="card">
         

                            
             <?php
                 if(mysqli_num_rows($prod)>0){
                     while($row= mysqli_fetch_assoc($prod)){
                          $stock= $row['bought']-$row['sold'];
                         echo "<tr>";
                         echo " <td>".$row['name']."</td>";

                         echo " <td>".$row['quantity']."</td>";

                         echo  " <td>".$row['quantity']."</td>";

                         echo " <td>".$stock."</td>";
                    }
                 }

            //  ?>
        </div> -->
    </div>

</div>


</body>
</html>
