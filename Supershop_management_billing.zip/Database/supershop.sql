-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 15, 2022 at 02:18 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `supershop`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `Id` bigint(20) NOT NULL,
  `Name` varchar(20) NOT NULL,
  `password` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`Id`, `Name`, `password`) VALUES
(1, 'admin1', 1234);

-- --------------------------------------------------------

--
-- Table structure for table `admintable`
--

CREATE TABLE `admintable` (
  `id` int(255) NOT NULL,
  `user` varchar(255) NOT NULL,
  `pass` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admintable`
--

INSERT INTO `admintable` (`id`, `user`, `pass`) VALUES
(1, 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `cashiertable`
--

CREATE TABLE `cashiertable` (
  `cashier_id` bigint(20) NOT NULL,
  `cashier_name` varchar(50) NOT NULL,
  `mobile_number` bigint(20) NOT NULL,
  `address` varchar(50) NOT NULL,
  `email_id` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cashiertable`
--

INSERT INTO `cashiertable` (`cashier_id`, `cashier_name`, `mobile_number`, `address`, `email_id`, `password`) VALUES
(14, 'mizanur', 1716167014, 'abcd', 'mizanurewu@gmail.com', '123456'),
(13, 'XYZ', 1716167014, 'Bangladesh', 'XYZ@gmail.com', '123456');

-- --------------------------------------------------------

--
-- Table structure for table `customertable`
--

CREATE TABLE `customertable` (
  `customer_id` bigint(20) NOT NULL,
  `customer_name` varchar(50) NOT NULL,
  `mobile_number` bigint(20) NOT NULL,
  `address` varchar(50) NOT NULL,
  `email_id` varchar(50) NOT NULL,
  `total_point` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customertable`
--

INSERT INTO `customertable` (`customer_id`, `customer_name`, `mobile_number`, `address`, `email_id`, `total_point`) VALUES
(7, 'Mizanur Rahman', 1716167014, 'kjkk,', 'mizanurewu@gmail.com', 0),
(8, 'Mizanur Rahman', 1716167014, 'jhkhklj', 'mizanurewu@gmail.com', 100),
(9, 'Mizanur Rahman', 1716167014, 'DFDF', 'mizanurewu@gmail.com', 10);

-- --------------------------------------------------------

--
-- Table structure for table `notice_table`
--

CREATE TABLE `notice_table` (
  `notice_id` int(10) NOT NULL,
  `Notice` varchar(100) NOT NULL,
  `Time` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `notice_table`
--

INSERT INTO `notice_table` (`notice_id`, `Notice`, `Time`) VALUES
(0, '', '00:00:00'),
(0, 'gee', '00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` bigint(20) NOT NULL,
  `name` varchar(100) NOT NULL,
  `quantity` bigint(20) NOT NULL,
  `product_price` double NOT NULL,
  `category` varchar(100) NOT NULL,
  `sold` bigint(20) NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `quantity`, `product_price`, `category`, `sold`, `updated_at`) VALUES
(1, 'tomato', 57, 10, 'vegetable', 23, '2022-04-15 12:09:44'),
(2, 'potato', 22, 9, 'vegetable', 49, '2022-04-15 12:09:30'),
(3, 'beef', 52, 600, 'meat', 52, '2022-04-15 11:49:55'),
(4, 'chicken', 10, 100, 'meat', 20, '2022-01-08 14:09:54'),
(5, 'kitkat', 38, 50, 'chocolate', 12, '2022-01-01 14:53:39'),
(6, 'sd', 431, 1000, 'veg', 13, '2022-01-11 20:04:49'),
(7, 'EGG', 26, 10, 'GROCERY', 4, '2022-01-23 05:47:53'),
(8, 'ssd', 8, 102, 'com', 2, '2022-01-11 20:05:23'),
(9, 'gold', 10, 10000, 'abc', 0, '2022-01-12 17:04:32'),
(10, 'egg', 110, 10, 'gro', 0, '2022-01-23 05:47:53'),
(11, 'chilli', 100, 20, 'vegitable', 0, '2022-04-15 11:52:08');

-- --------------------------------------------------------

--
-- Table structure for table `stafftable`
--

CREATE TABLE `stafftable` (
  `staff_id` bigint(20) NOT NULL,
  `staff_name` varchar(50) NOT NULL,
  `mobile_number` bigint(50) NOT NULL,
  `address` varchar(50) NOT NULL,
  `email_id` varchar(50) NOT NULL,
  `nid_number` bigint(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `stafftable`
--

INSERT INTO `stafftable` (`staff_id`, `staff_name`, `mobile_number`, `address`, `email_id`, `nid_number`) VALUES
(12, 'abc', 1716167014, 'dadfs', 'mizanurewu@gmail.com', 545454),
(11, 'ABCD', 1716167014, 'DShaka', 'ABCD@gmail.com', 123452),
(10, 'hello', 1716167014, 'fda', 'mizanurewdu@gmail.com', 45456),
(9, 'mohon', 123568, 'dhaka', 'fhdid', 123654),
(8, 'Robin', 185632984, 'Uttara', 'Robin@gmail.com', 123556978);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`Id`),
  ADD KEY `Name` (`Name`),
  ADD KEY `password` (`password`);

--
-- Indexes for table `admintable`
--
ALTER TABLE `admintable`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cashiertable`
--
ALTER TABLE `cashiertable`
  ADD PRIMARY KEY (`cashier_id`),
  ADD KEY `cashier_name` (`cashier_name`,`mobile_number`,`address`,`email_id`,`password`);

--
-- Indexes for table `customertable`
--
ALTER TABLE `customertable`
  ADD PRIMARY KEY (`customer_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `stafftable`
--
ALTER TABLE `stafftable`
  ADD PRIMARY KEY (`staff_id`),
  ADD KEY `staff_name` (`staff_name`,`mobile_number`,`address`,`email_id`,`nid_number`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `Id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `admintable`
--
ALTER TABLE `admintable`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `cashiertable`
--
ALTER TABLE `cashiertable`
  MODIFY `cashier_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `customertable`
--
ALTER TABLE `customertable`
  MODIFY `customer_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `stafftable`
--
ALTER TABLE `stafftable`
  MODIFY `staff_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
