
<?php

$conn = mysqli_connect('localhost', 'root', '', 'supershop');
if(isset($_POST['save']))
{	 
	 $staff_name = $_POST['staff_name'];
	 $mobile_number = $_POST['mobile_number'];
	 $address = $_POST['address'];
	 $email_id = $_POST['email_id'];
	 $nid_number = $_POST['nid_number'];
 
	 $sql = "INSERT INTO stafftable (staff_name, mobile_number, address, email_id, nid_number) 
	 VALUES ('$staff_name','$mobile_number','$address', '$email_id', '$nid_number')";
	 if (mysqli_query($conn, $sql)){
		echo "New record created successfully !";
	  }
	  else {
		echo "Error: ";
	 }
	 
	 mysqli_close($conn);
}
?>