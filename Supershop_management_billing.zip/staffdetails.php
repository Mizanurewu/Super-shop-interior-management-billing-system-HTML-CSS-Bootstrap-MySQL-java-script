<?php
session_start();
include 'connection.php';
$conn=connect();

$query= "select * from stafftable";
$result = mysqli_query($conn,$query);

?>

<html>
<head >
        <title> Staff Details </title>
</head>
<body  style="background-color:lightblue;">
      <table class="table" align="center" border="1px" >
        <tr>
        <th colspan="5"  <h2> Cashier Record</h2> </th>
         </tr>
         <tr>
          <th>Staff Id</th>
          <th>Staff Name </th>
          <th>Staff Number </th>
          <th>Staff Adrress </th>
          <th>Staff Email </th>
        </tr>

        <?php

        while($rows=mysqli_fetch_assoc($result))
        {
        ?>
        <tr>
          <td>  <?php echo $rows['staff_id'] ?>  </td>
            <td>    <?php echo $rows['staff_name'] ?>     </td>
             <td>    <?php echo $rows['mobile_number'] ?>     </td>
            <td>     <?php echo $rows['address'] ?>    </td>
            <td>     <?php echo $rows['email_id'] ?>    </td>
        </tr>
      <?php
   }
   ?>
      </table>
        <li style="padding-left: 400px;"><a href="dashboard.php"><button type="button" autofocus>Home Page</button></a></li>
</body>
</html>
