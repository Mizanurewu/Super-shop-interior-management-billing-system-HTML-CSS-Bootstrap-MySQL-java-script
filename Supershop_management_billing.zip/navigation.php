<?php
    $user= $_SESSION['user'];
?>
<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=10" >
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

    </head>
    <body>
        <nav class="navbar-inverse navbar-fixed-top" >
                <ul class="nav navbar-nav" style="color: white;">
                    <li><a class="active" href="dashboard.php">Home Page</a></li>
                    <li><a href="addcashier.php">Add cashier</a></li>
                    <li><a href="viewcashierdetails.php">View Cashier Details</a></li>
                    <li><a href="addstaff.php">Add staff</a></li>
                    <li><a href="staffdetails.php">View Stuff Details</a></li>
                    <li><a href="addcustomer.php">Customers</a></li>
                    <li><a href="addProduct.php">Add Products</a></li>
                    <li><a href="product_update.php">Update Product</a></li>
                    <li><a href="stock.php">Stock </a></li>
                    <li><a href="most_sold_product.php">Most Sold Product</a>
                    </li>
                    <li> <a href ="sales_per_weak.php"> Sales as Per Week</a>
                    </li> 
                    <li><a href="billpage.php">Bill</a></li>
                    <li style="float: right;"><a href="logout.php" style="padding: 0px 20px 0px 0px;">
                        <button class=" btn-danger navbar-btn pull-right">Logout
                        </button></a></li>
                    <li class="pull-right"><a href="#">Logged in as <b class="user"><?php echo $user; ?></b></a></li>

                </ul>
            
        </nav>
    </body>
</html>
