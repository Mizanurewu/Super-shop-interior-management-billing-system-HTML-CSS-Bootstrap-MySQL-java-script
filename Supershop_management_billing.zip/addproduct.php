<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<?php  include 'links.php' ?>
</head>
<body>

<header>
	<div class="container center-div ">
		
		<div class="container row justify-content-center">
					<form action="addproductprocess.php" method="POST">
						<div class="form-group">
							<div class="heading text-center text-uppercase text-white"style="background-color: blue;"> ADD PRODUCT 	DETATLS 
		</div>
							<label>Product Name</label>
							<input type="text" name="product_name" value="" class="form-control">
						</div>

						<div class="form-group">
							<label>Quantity</label>
							<input type="text" name="quantity" value="" class="form-control">
						</div>

						<div class="form-group">
							<label>Price</label>
							<input type="text" name="price" value="" class="form-control">
						</div>

						<div class="form-group">
							<label>Category</label>
							<input type="text" name="category" value="" class="form-control" >
						</div>
						<input type="submit"name= "save" value="submit" >
				</form>
		</div>
	</div>
</header>

</body>
</html>
