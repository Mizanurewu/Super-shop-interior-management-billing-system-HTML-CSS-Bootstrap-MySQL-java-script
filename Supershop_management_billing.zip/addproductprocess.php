
<?php

$conn = mysqli_connect('localhost', 'root', '', 'supershop');
if(isset($_POST['save']))
{
	 $product_name = $_POST['product_name'];
	 $quantity = $_POST['quantity'];
	 $price = $_POST['price'];
	 $category = $_POST['category'];

	 $sql = "INSERT INTO products (name, quantity, product_price, category)
	 VALUES ('$product_name','$quantity', '$price', '$category')";
	 if (mysqli_query($conn, $sql)) {
		echo "New record created successfully !";
	 } else {
	 	echo "FAIL";
	 }
	 mysqli_close($conn);
}
?>
