<?php
session_start();
include 'connection.php';
$conn=connect();
     if(isset($_POST['save']))
     {
        $name = $_POST['name'];
        $qunt = $_POST['qunt'];

        $sql = "UPDATE `products` SET `quantity`=quantity+'$qunt' WHERE (name = '$name' and '$qunt' > 0);";
             if (mysqli_query($conn, $sql)) {
                echo "Product Update successfull!";
                header("location:product_update.php");

     } else {
        echo "Error: " . $sql . "
" . mysqli_error($conn);
     }
     mysqli_close($conn);
     }

?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Product Update</title>
    <link rel="stylesheet" type="text/css" href="style.css">
    <?php  include 'links.php' ?>
</head>
<body>
<header>
    <div class="container center-div ">
        
        <div class="container row justify-content-center">

                    <form action="product_update.php" method="POST">
                        <div class="heading text-center text-uppercase text-white"style="background-color: blue;"> Product Update
                        </div>
                        <div class="form-group">
                            <label>Product Name</label>
                            <select name="name" class="form-control">
                              <?php 
                                 $sql = "SELECT * FROM products";
                                 $query = mysqli_query($conn,$sql);
         
                                 while($row = mysqli_fetch_assoc($query)){
                                ?>
                              <option id="<?php echo $row['id']; ?>" value="<?php echo $row['name']; ?>">
                                 <?php echo $row['name']; ?>
                              </option>
                              <?php  }?>   
                           </select>
                        </div>

                        <div class="form-group">
                            <label>Quantity</label>
                            <input type="text" name="qunt" value="" class="form-control" autocomplete="off">
                        </div>
                        <input type="submit" autocomplete="off" name= "save" value="submit" >
                        <br>
                        <a href="dashboard.php" style="padding: 0px 20px 0px 0px;float: left;"><button type="button">Home Page</button>
                        </a>


                </form>

            

        </div>
    </div>

</header>
</body>
</html>