<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<?php  include 'links.php' ?>
</head>
<body>

<header>
	<div class="container center-div shadow ">
		
		<div class="container row justify-content-center">


					<form action="addcustomerprocess.php" method="POST">
					
						<div class="form-group">
							<div class="heading text-center text-uppercase text-white" style="background-color: blue;"> ADD CUSTOMER DETAILS 
							</div>
							<label>Customer Name</label>
							<input type="text" name="customer_name" value="" class="form-control">
						</div>

						<div class="form-group">
							<label>Mobile Number</label>
							<input type="text" name="mobile_number" value="" class="form-control" >
						</div>

						<div class="form-group">
							<label>Address</label>
							<input type="text" name="address" value="" class="form-control" >
						</div>

						<div class="form-group">
							<label>Email ID</label>
							<input type="text" name="email_id" value="" class="form-control" >
						</div>
						<div class="form-group">
							<label>Total Point</label>
							<input type="text" name="total_point" value="" class="form-control" >
						</div>
						<input type="submit"name= "save" value="submit" >
						
				</form>	
		</div>
	</div>
</header>

</body>
</html>