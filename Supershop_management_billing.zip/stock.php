<?php
session_start();
include 'connection.php';
$conn=connect();

$query= "select * from products";
$result = mysqli_query($conn,$query);
?>
<html>
<head>

        <link rel="stylesheet" type="text/css" href="style.css">
        <title> Cashier Details </title>
        <style>
  body {
    background-color: lightblue;
  }
  </style>

</style>
</head>
<body>
  <div align="center">
      <table class="table" border="1px" width="600px">

        <tr>
        <th colspan="4"  <h2>Stock</h2> </th>
         </tr>
         <tr>
          <!-- <th></th> -->
          <th>ProductName </th>
          <th>Quantity</th>
          <th>Price </th>
          <th>Category</th>

        </tr>

        <?php

        while($rows=mysqli_fetch_assoc($result))
        {
     ?>
        <tr>
          <td>  <?php echo $rows['name'] ?>  </td>


            <td>    <?php echo $rows['quantity'] ?>  </td>

             <td>    <?php echo $rows['product_price'] ?> </td>
             <td>     <?php echo $rows['category'] ?>  </td>

        </tr>
      <?php
   }
   ?>


 </table>
 </div>
        <li style="padding-left: 380px;"><a href="dashboard.php"><button type="button" autofocus>Home Page</button></a></li>

</body>
</html>
