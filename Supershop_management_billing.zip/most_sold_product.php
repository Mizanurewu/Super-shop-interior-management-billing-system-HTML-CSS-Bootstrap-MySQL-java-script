<?php
session_start();
include 'navigation.php';
include 'connection.php';

$conn=connect();
$sql= "SELECT name,SUM(sold) from products group by name order by SUM(sold) desc limit 3";
$prod=$conn->query($sql);
$result = mysqli_query($conn,$sql);
   
?>
<html>
<head>
        <link rel="stylesheet" type="text/css" href="style.css">
        <title> Cashier Details </title>
        <style>
            body {
                     background-color: lightblue;
                }
        </style>

</style>
</head>
<body>
  <div align="center" style="padding-top: 150px;padding-left: 10px;" >
      <table border="2px"  style="width:600px">

        <tr>
        <th colspan="4"  <h2>Most Sold product</h2> </th>
         </tr>
         <tr>
          <!-- <th></th> -->
            <th>ProductName </th>
            <th> Sold <th>
        
        </tr>

        <?php

        while($rows=mysqli_fetch_assoc($result))
        {
                ?>
          <tr>
               <td>  <?php echo $rows['name'] ?>  </td>
               <td>  <?php echo $rows['SUM(sold)'] ?>     </td>

          </tr>
             <?php
              } ?>
          

      </table>
      <div style="float:left; padding-left: 380px;"> <li><a href="dashboard.php" ><button type="button">Home Page</button></a></li></div>
           
 </div>
</body>
</html>
